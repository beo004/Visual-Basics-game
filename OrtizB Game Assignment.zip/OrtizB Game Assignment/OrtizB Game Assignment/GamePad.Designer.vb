﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class GamePad
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(GamePad))
        Me.SpaceMover = New System.Windows.Forms.Timer(Me.components)
        Me.Ship = New System.Windows.Forms.PictureBox()
        Me.Left_Mover = New System.Windows.Forms.Timer(Me.components)
        Me.Right_Mover = New System.Windows.Forms.Timer(Me.components)
        Me.Enemy1 = New System.Windows.Forms.PictureBox()
        Me.Enemy3 = New System.Windows.Forms.PictureBox()
        Me.Enemy2 = New System.Windows.Forms.PictureBox()
        Me.Enemy1_Mover = New System.Windows.Forms.Timer(Me.components)
        Me.Enemy2_Mover = New System.Windows.Forms.Timer(Me.components)
        Me.Enemy3_Mover = New System.Windows.Forms.Timer(Me.components)
        Me.lblGame = New System.Windows.Forms.Label()
        Me.Score_Text = New System.Windows.Forms.Label()
        Me.BtnBack = New System.Windows.Forms.Button()
        Me.BtnReplay = New System.Windows.Forms.Button()
        Me.LblName = New System.Windows.Forms.Label()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.ToolTip2 = New System.Windows.Forms.ToolTip(Me.components)
        CType(Me.Ship, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Enemy1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Enemy3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Enemy2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SpaceMover
        '
        Me.SpaceMover.Enabled = True
        Me.SpaceMover.Interval = 10
        '
        'Ship
        '
        Me.Ship.BackColor = System.Drawing.Color.Transparent
        Me.Ship.Image = CType(resources.GetObject("Ship.Image"), System.Drawing.Image)
        Me.Ship.Location = New System.Drawing.Point(138, 606)
        Me.Ship.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Ship.Name = "Ship"
        Me.Ship.Size = New System.Drawing.Size(58, 79)
        Me.Ship.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Ship.TabIndex = 0
        Me.Ship.TabStop = False
        '
        'Left_Mover
        '
        Me.Left_Mover.Interval = 10
        '
        'Right_Mover
        '
        Me.Right_Mover.Interval = 10
        '
        'Enemy1
        '
        Me.Enemy1.BackColor = System.Drawing.Color.Transparent
        Me.Enemy1.Image = CType(resources.GetObject("Enemy1.Image"), System.Drawing.Image)
        Me.Enemy1.Location = New System.Drawing.Point(13, 423)
        Me.Enemy1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Enemy1.Name = "Enemy1"
        Me.Enemy1.Size = New System.Drawing.Size(58, 88)
        Me.Enemy1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Enemy1.TabIndex = 1
        Me.Enemy1.TabStop = False
        '
        'Enemy3
        '
        Me.Enemy3.BackColor = System.Drawing.Color.Transparent
        Me.Enemy3.Image = CType(resources.GetObject("Enemy3.Image"), System.Drawing.Image)
        Me.Enemy3.Location = New System.Drawing.Point(248, 247)
        Me.Enemy3.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Enemy3.Name = "Enemy3"
        Me.Enemy3.Size = New System.Drawing.Size(58, 88)
        Me.Enemy3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Enemy3.TabIndex = 2
        Me.Enemy3.TabStop = False
        '
        'Enemy2
        '
        Me.Enemy2.BackColor = System.Drawing.Color.Transparent
        Me.Enemy2.Image = CType(resources.GetObject("Enemy2.Image"), System.Drawing.Image)
        Me.Enemy2.Location = New System.Drawing.Point(138, 14)
        Me.Enemy2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Enemy2.Name = "Enemy2"
        Me.Enemy2.Size = New System.Drawing.Size(58, 88)
        Me.Enemy2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Enemy2.TabIndex = 5
        Me.Enemy2.TabStop = False
        '
        'Enemy1_Mover
        '
        Me.Enemy1_Mover.Enabled = True
        Me.Enemy1_Mover.Interval = 10
        '
        'Enemy2_Mover
        '
        Me.Enemy2_Mover.Enabled = True
        Me.Enemy2_Mover.Interval = 10
        '
        'Enemy3_Mover
        '
        Me.Enemy3_Mover.Enabled = True
        Me.Enemy3_Mover.Interval = 10
        '
        'lblGame
        '
        Me.lblGame.AutoSize = True
        Me.lblGame.BackColor = System.Drawing.Color.Transparent
        Me.lblGame.Font = New System.Drawing.Font("Felix Titling", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGame.ForeColor = System.Drawing.Color.Red
        Me.lblGame.Location = New System.Drawing.Point(55, 149)
        Me.lblGame.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblGame.Name = "lblGame"
        Me.lblGame.Size = New System.Drawing.Size(222, 38)
        Me.lblGame.TabIndex = 6
        Me.lblGame.Text = "Game Over!"
        Me.lblGame.Visible = False
        '
        'Score_Text
        '
        Me.Score_Text.AutoSize = True
        Me.Score_Text.BackColor = System.Drawing.Color.Transparent
        Me.Score_Text.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Score_Text.ForeColor = System.Drawing.Color.Red
        Me.Score_Text.Location = New System.Drawing.Point(5, 9)
        Me.Score_Text.Name = "Score_Text"
        Me.Score_Text.Size = New System.Drawing.Size(72, 21)
        Me.Score_Text.TabIndex = 7
        Me.Score_Text.Text = "Score: 0"
        '
        'BtnBack
        '
        Me.BtnBack.BackColor = System.Drawing.Color.Black
        Me.BtnBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnBack.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnBack.ForeColor = System.Drawing.Color.Red
        Me.BtnBack.Location = New System.Drawing.Point(99, 190)
        Me.BtnBack.Name = "BtnBack"
        Me.BtnBack.Size = New System.Drawing.Size(145, 39)
        Me.BtnBack.TabIndex = 8
        Me.BtnBack.Text = "Home Page"
        Me.ToolTip2.SetToolTip(Me.BtnBack, "Returns to Home Page")
        Me.BtnBack.UseVisualStyleBackColor = False
        Me.BtnBack.Visible = False
        '
        'BtnReplay
        '
        Me.BtnReplay.BackColor = System.Drawing.Color.Black
        Me.BtnReplay.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnReplay.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnReplay.ForeColor = System.Drawing.Color.Red
        Me.BtnReplay.Location = New System.Drawing.Point(99, 235)
        Me.BtnReplay.Name = "BtnReplay"
        Me.BtnReplay.Size = New System.Drawing.Size(145, 39)
        Me.BtnReplay.TabIndex = 9
        Me.BtnReplay.Text = "Replay"
        Me.ToolTip1.SetToolTip(Me.BtnReplay, "Replays Game")
        Me.BtnReplay.UseVisualStyleBackColor = False
        Me.BtnReplay.Visible = False
        '
        'LblName
        '
        Me.LblName.AutoSize = True
        Me.LblName.BackColor = System.Drawing.Color.Transparent
        Me.LblName.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblName.ForeColor = System.Drawing.Color.Red
        Me.LblName.Location = New System.Drawing.Point(203, 9)
        Me.LblName.Name = "LblName"
        Me.LblName.Size = New System.Drawing.Size(62, 21)
        Me.LblName.TabIndex = 10
        Me.LblName.Text = "Name: "
        Me.LblName.Visible = False
        '
        'GamePad
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(17.0!, 44.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(319, 699)
        Me.Controls.Add(Me.LblName)
        Me.Controls.Add(Me.BtnReplay)
        Me.Controls.Add(Me.BtnBack)
        Me.Controls.Add(Me.Score_Text)
        Me.Controls.Add(Me.lblGame)
        Me.Controls.Add(Me.Enemy2)
        Me.Controls.Add(Me.Enemy3)
        Me.Controls.Add(Me.Enemy1)
        Me.Controls.Add(Me.Ship)
        Me.Font = New System.Drawing.Font("Viner Hand ITC", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(9)
        Me.Name = "GamePad"
        Me.Text = "Form1"
        CType(Me.Ship, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Enemy1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Enemy3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Enemy2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents SpaceMover As Timer
    Friend WithEvents Ship As PictureBox
    Friend WithEvents Left_Mover As Timer
    Friend WithEvents Right_Mover As Timer
    Friend WithEvents Enemy3 As PictureBox
    Friend WithEvents Enemy1 As PictureBox
    Friend WithEvents Enemy2 As PictureBox
    Friend WithEvents Enemy1_Mover As Timer
    Friend WithEvents Enemy2_Mover As Timer
    Friend WithEvents Enemy3_Mover As Timer
    Friend WithEvents lblGame As Label
    Friend WithEvents Score_Text As Label
    Friend WithEvents BtnBack As Button
    Friend WithEvents BtnReplay As Button
    Friend WithEvents LblName As Label
    Friend WithEvents ToolTip2 As ToolTip
    Friend WithEvents ToolTip1 As ToolTip
End Class
