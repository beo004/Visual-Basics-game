﻿Public Class GamePad
    Dim Scores As Integer = 0
    Dim speed As Integer
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        speed = 10
        If Scores > 10 And speed < 20 Then
            speed = 12
        End If
        If Scores > 20 And Scores < 30 Then
            speed = 15
        End If
        If Scores > 30 Then
            speed = 20
        End If
    End Sub

    Private Sub GameOver()
        BtnBack.Visible = True
        BtnReplay.Visible = True
        lblGame.Visible = True
        Enemy1_Mover.Stop()
        Enemy2_Mover.Stop()
        Enemy3_Mover.Stop()
    End Sub
    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Left Then
            Left_Mover.Start()
        End If
        If e.KeyCode = Keys.Right Then
            Right_Mover.Start()
        End If
    End Sub
    Private Sub Left_Mover_Tick(sender As Object, e As EventArgs) Handles Left_Mover.Tick
        If (Ship.Location.X > 12) Then
            Ship.Left -= 15
        End If
    End Sub
    Private Sub Right_Mover_Tick(sender As Object, e As EventArgs) Handles Right_Mover.Tick
        If (Ship.Location.X < 240) Then
            Ship.Left += 15
        End If
    End Sub

    Private Sub Form1_KeyUp(sender As Object, e As KeyEventArgs) Handles MyBase.KeyUp
        Left_Mover.Stop()
        Right_Mover.Stop()
    End Sub

    Private Sub Enemy1_Mover_Tick(sender As Object, e As EventArgs) Handles Enemy1_Mover.Tick
        Enemy1.Top += speed + 7
        If Enemy1.Top >= Me.Height Then
            Scores += 1
            Score_Text.Text = "Score: " & Scores
            Enemy1.Top = -(CInt(Math.Ceiling(Rnd() * 150)) + Enemy1.Height)
            Enemy1.Left = CInt(Math.Ceiling(Rnd() * 200)) + 50
        End If
    End Sub

    Private Sub Enemy2_Mover_Tick(sender As Object, e As EventArgs) Handles Enemy2_Mover.Tick
        Enemy2.Top += speed + 10
        If Enemy2.Top >= Me.Height Then
            Scores += 1
            Score_Text.Text = "Score: " & Scores
            Enemy2.Top = Enemy2.Top = -(CInt(Math.Ceiling(Rnd() * 150)) + Enemy2.Height)
            Enemy2.Left = Enemy2.Top = CInt(Math.Ceiling(Rnd() * 100)) + 150
        End If
    End Sub

    Private Sub Enemy3_Mover_Tick(sender As Object, e As EventArgs) Handles Enemy3_Mover.Tick
        Enemy3.Top += speed + 5
        If Enemy3.Top >= Me.Height Then
            Scores += 1
            Score_Text.Text = "Score: " & Scores
            Enemy3.Top = -(CInt(Math.Ceiling(Rnd() * 150)) + Enemy3.Height)
            Enemy3.Left = CInt(Math.Ceiling(Rnd() * 150)) + 100
        End If
    End Sub

    Private Sub SpaceMover_Tick(sender As Object, e As EventArgs) Handles SpaceMover.Tick
        If (Ship.Bounds.IntersectsWith(Enemy1.Bounds)) Then
            GameOver()
        End If
        If (Ship.Bounds.IntersectsWith(Enemy2.Bounds)) Then
            GameOver()
        End If
        If (Ship.Bounds.IntersectsWith(Enemy3.Bounds)) Then
            GameOver()
        End If
    End Sub

    Private Sub BtnBack_Click(sender As Object, e As EventArgs) Handles BtnBack.Click
        Dim AskPlayer As String = InputBox("Please Enter A Name!")
        LblName.Text = "Name: " & AskPlayer
        Dim sw As IO.StreamWriter = IO.File.AppendText("Players-Score.txt")
        sw.WriteLine(AskPlayer & ", " & Score_Text.Text)
        sw.Close()
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles BtnReplay.Click
        Scores = 0
        Me.Controls.Clear()
        InitializeComponent()
        Form1_Load(e, e)
    End Sub
End Class
