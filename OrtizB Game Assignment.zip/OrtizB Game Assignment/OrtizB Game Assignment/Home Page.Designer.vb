﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Home_Page
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Home_Page))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BtnInstructions = New System.Windows.Forms.Button()
        Me.BtnPlay = New System.Windows.Forms.Button()
        Me.BtnLeaderBoard = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Red
        Me.Label1.Location = New System.Drawing.Point(68, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(208, 42)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Alien Evader"
        '
        'BtnInstructions
        '
        Me.BtnInstructions.BackColor = System.Drawing.Color.Black
        Me.BtnInstructions.Font = New System.Drawing.Font("Times New Roman", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnInstructions.ForeColor = System.Drawing.Color.Red
        Me.BtnInstructions.Location = New System.Drawing.Point(75, 200)
        Me.BtnInstructions.Name = "BtnInstructions"
        Me.BtnInstructions.Size = New System.Drawing.Size(201, 64)
        Me.BtnInstructions.TabIndex = 1
        Me.BtnInstructions.Text = "How to Play"
        Me.ToolTip1.SetToolTip(Me.BtnInstructions, "Gives Instructions")
        Me.BtnInstructions.UseVisualStyleBackColor = False
        '
        'BtnPlay
        '
        Me.BtnPlay.BackColor = System.Drawing.Color.Black
        Me.BtnPlay.Font = New System.Drawing.Font("Times New Roman", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnPlay.ForeColor = System.Drawing.Color.Red
        Me.BtnPlay.Location = New System.Drawing.Point(75, 125)
        Me.BtnPlay.Name = "BtnPlay"
        Me.BtnPlay.Size = New System.Drawing.Size(201, 69)
        Me.BtnPlay.TabIndex = 2
        Me.BtnPlay.Text = "Play"
        Me.ToolTip1.SetToolTip(Me.BtnPlay, "Plays Game")
        Me.BtnPlay.UseVisualStyleBackColor = False
        '
        'BtnLeaderBoard
        '
        Me.BtnLeaderBoard.BackColor = System.Drawing.Color.Black
        Me.BtnLeaderBoard.Font = New System.Drawing.Font("Times New Roman", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLeaderBoard.ForeColor = System.Drawing.Color.Red
        Me.BtnLeaderBoard.Location = New System.Drawing.Point(75, 270)
        Me.BtnLeaderBoard.Name = "BtnLeaderBoard"
        Me.BtnLeaderBoard.Size = New System.Drawing.Size(201, 64)
        Me.BtnLeaderBoard.TabIndex = 3
        Me.BtnLeaderBoard.Text = "Leaderboard"
        Me.ToolTip1.SetToolTip(Me.BtnLeaderBoard, "Shows LeaderBoard")
        Me.BtnLeaderBoard.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Black
        Me.Button1.Font = New System.Drawing.Font("Times New Roman", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.Red
        Me.Button1.Location = New System.Drawing.Point(75, 340)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(201, 69)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "Exit"
        Me.ToolTip1.SetToolTip(Me.Button1, "Exits Program")
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Home_Page
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 23.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(346, 578)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.BtnLeaderBoard)
        Me.Controls.Add(Me.BtnPlay)
        Me.Controls.Add(Me.BtnInstructions)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.Name = "Home_Page"
        Me.Text = "Home_Page"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents BtnInstructions As Button
    Friend WithEvents BtnPlay As Button
    Friend WithEvents BtnLeaderBoard As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents ToolTip1 As ToolTip
End Class
