﻿Public Class Home_Page
    Dim Player() As String
    Dim Record As Integer = 0
    Private Sub BtnInstructions_Click(sender As Object, e As EventArgs) Handles BtnInstructions.Click
        Instructions.ShowDialog()
    End Sub

    Private Sub BtnPlay_Click(sender As Object, e As EventArgs) Handles BtnPlay.Click
        GamePad.ShowDialog()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles BtnLeaderBoard.Click
        Leaderboard.ShowDialog()
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        Dim DialogueResult As MsgBoxResult
        DialogueResult = MessageBox.Show("Are you sure you want to exit?", "EXIT?", MessageBoxButtons.YesNo)
        If DialogueResult = MsgBoxResult.Yes Then
            End
        Else
            If DialogueResult = MsgBoxResult.No Then
                MsgBox("Good Choice!")
                Return
            End If
        End If
    End Sub
End Class
