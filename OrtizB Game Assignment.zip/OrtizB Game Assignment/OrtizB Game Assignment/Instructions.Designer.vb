﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Instructions
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Instructions))
        Me.LBLInstruct = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.LblObj = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.BtnInstructions = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.SuspendLayout()
        '
        'LBLInstruct
        '
        Me.LBLInstruct.AutoSize = True
        Me.LBLInstruct.BackColor = System.Drawing.Color.Transparent
        Me.LBLInstruct.ForeColor = System.Drawing.Color.Red
        Me.LBLInstruct.Location = New System.Drawing.Point(13, 13)
        Me.LBLInstruct.Name = "LBLInstruct"
        Me.LBLInstruct.Size = New System.Drawing.Size(119, 23)
        Me.LBLInstruct.TabIndex = 0
        Me.LBLInstruct.Text = "Instructions: "
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.TextBox1.ForeColor = System.Drawing.Color.Red
        Me.TextBox1.Location = New System.Drawing.Point(12, 39)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(456, 55)
        Me.TextBox1.TabIndex = 1
        Me.TextBox1.Text = "Use the Left and Right Arrow Keys to move the ship left and right."
        '
        'LblObj
        '
        Me.LblObj.AutoSize = True
        Me.LblObj.BackColor = System.Drawing.Color.Transparent
        Me.LblObj.ForeColor = System.Drawing.Color.Red
        Me.LblObj.Location = New System.Drawing.Point(8, 109)
        Me.LblObj.Name = "LblObj"
        Me.LblObj.Size = New System.Drawing.Size(104, 23)
        Me.LblObj.TabIndex = 2
        Me.LblObj.Text = "Objectives:"
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.TextBox2.ForeColor = System.Drawing.Color.Red
        Me.TextBox2.Location = New System.Drawing.Point(12, 135)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.Size = New System.Drawing.Size(456, 33)
        Me.TextBox2.TabIndex = 3
        Me.TextBox2.Text = "Try to avoid the aliens from hitting your ship."
        '
        'BtnInstructions
        '
        Me.BtnInstructions.BackColor = System.Drawing.Color.Black
        Me.BtnInstructions.Font = New System.Drawing.Font("Times New Roman", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnInstructions.ForeColor = System.Drawing.Color.Red
        Me.BtnInstructions.Location = New System.Drawing.Point(143, 194)
        Me.BtnInstructions.Name = "BtnInstructions"
        Me.BtnInstructions.Size = New System.Drawing.Size(201, 64)
        Me.BtnInstructions.TabIndex = 4
        Me.BtnInstructions.Text = "Return"
        Me.ToolTip1.SetToolTip(Me.BtnInstructions, "Retruns to Home Page")
        Me.BtnInstructions.UseVisualStyleBackColor = False
        '
        'Instructions
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 23.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(506, 270)
        Me.Controls.Add(Me.BtnInstructions)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.LblObj)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.LBLInstruct)
        Me.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.Name = "Instructions"
        Me.Text = "Instructions"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents LBLInstruct As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents LblObj As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents BtnInstructions As Button
    Friend WithEvents ToolTip1 As ToolTip
End Class
