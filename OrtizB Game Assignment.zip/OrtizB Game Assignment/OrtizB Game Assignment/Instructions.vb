﻿Public Class Instructions
    Private Sub Instructions_Load(sender As Object, e As EventArgs) Handles MyBase.Load


    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub BtnInstructions_Click(sender As Object, e As EventArgs) Handles BtnInstructions.Click
        Me.Close()
    End Sub
End Class