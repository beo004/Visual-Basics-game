﻿Public Class Leaderboard
    Private Sub Leaderboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim scoreboard() As String = IO.File.ReadAllLines("Players-Score.txt")
        Dim QueryLeader = From Line In scoreboard
                          Let data = Line.Split(",")
                          Let name = data(0)
                          Let score = data(1)
                          Order By score Descending
                          Select name, score

        DGVLeaderboard.DataSource = QueryLeader.ToList
        DGVLeaderboard.Columns("name").HeaderText = "Player"
        DGVLeaderboard.Columns("score").HeaderText = "Score"
    End Sub

    Private Sub BtnLeaderBoard_Click(sender As Object, e As EventArgs) Handles BtnLeaderBoard.Click
        Me.Close()
    End Sub
End Class
